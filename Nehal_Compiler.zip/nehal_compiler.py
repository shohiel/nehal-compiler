import openai
from flask import Flask, render_template, request

# Set OpenAI API Key (Replace 'your_openai_api_key' with a valid key)
openai.api_key = "your_openai_api_key"

def generate_cpp_code(nl_input):
    prompt = f"Convert the following natural language instruction into C++ code:

Instruction: {nl_input}

C++ Code:"
    
    response = openai.ChatCompletion.create(
        model="gpt-4-turbo",
        messages=[{"role": "user", "content": prompt}]
    )

    return response["choices"][0]["message"]["content"].strip()

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    cpp_code = ""
    if request.method == "POST":
        nl_input = request.form["nl_input"]
        cpp_code = generate_cpp_code(nl_input)
    return render_template("index.html", cpp_code=cpp_code)

if __name__ == "__main__":
    app.run(debug=True)
